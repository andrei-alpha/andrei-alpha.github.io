This is the READ ME file.
Contains all the information needed to work on our project.
Don't mess with git, read http://git-scm.com/

Have a nice day!

Iar te-ai cufundat în stele 
Si în nori si-n ceruri nalte? 
De nu m-ai uita încalte, 
Sufletul vietii mele.


In zadar râuri de soare 
Gramadesti-n a ta gândire 
Si câmpiile asire 
Si întunecata mare;


Piramidele-nvechite 
Urca-n cer vârful lor mare
Nu cata în departare 
Fericirea ta, iubite!


Astfel zise mititica, 
Dulce netezindu-mi parul. 
Ah! ea spuse adevarul; 
Eu am râs, n-am zis nimica.


Hai în codrul cu verdeata, 
Und-izvoare plâng în vale, 
Stânca sta sa se pravale 
In prapastia mareata.


Acolo-n ochi de padure, 
Lânga balta cea senina 
Si sub trestia cea lina 
Vom sedea în foi de mure.


Si mi-i spune-atunci povesti 
Si minciuni cu-a ta gurita, 
Eu pe-un fir de romanita 
Voi cerca de ma iubesti.

Si de-a soarelui caldura 
Voi fi rosie ca marul, 
Mi-oi desface de-aur parul, 
Sa-ti astup cu dânsul gura.


De mi-i da o sarutare, 
Nime-n lume n-a s-o stie, 
Caci va fi sub palarie 
S-apoi cine treaba are!


Când prin crengi s-a fi ivit 
Luna-n noaptea cea de vara, 
Mi-i tinea de subsuoara, 
Te-oi tinea de dupa gât.


Pe carare-n bolti de frunze, 
Apucând spre sat în vale, 
Ne-om da sarutari pe cale, 
Dulci ca florile ascunse.


Si sosind l-al portii prag, 
Vom vorbi-n întunecime; 
Grija noastra n-aib-o nime, 
Cui ce-i pasa ca-mi esti drag?


Inc-o gura si dispare... 
Ca un stâlp eu stam în luna! 
Ce frumoasa, ce nebuna 
E albastra-mi, dulce floare!

................................................

Si te-ai dus, dulce minune, 
S-a murit iubirea noastra 
Floare-albastra! floare-albastra!... 
Totusi este trist în lume!
